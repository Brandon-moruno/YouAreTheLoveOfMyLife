const images=['img/foto1.jpg','img/foto2.jpg','img/foto3.jpg'];
let currentIndex=0;
const storyImage=document.getElementById('story-image');
const progress=document.querySelector('.progress');
const prevBtn=document.getElementById('prev');
const nextBtn=document.getElementById('next');
let interval;

function showImage(index){currentIndex=index;storyImage.src=images[currentIndex];progress.style.width='0%';setTimeout(()=>{progress.style.width='100%';},50);}
function nextImage(){currentIndex=(currentIndex+1)%images.length;showImage(currentIndex);}
function prevImage(){currentIndex=(currentIndex-1+images.length)%images.length;showImage(currentIndex);}

function startAuto(){interval=setInterval(nextImage,5000);}
function resetAuto(){clearInterval(interval);startAuto();}

nextBtn.addEventListener('click',()=>{nextImage();resetAuto();});
prevBtn.addEventListener('click',()=>{prevImage();resetAuto();});

startAuto();progress.style.width='100%';