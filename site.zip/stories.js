const audio=document.getElementById('audio');const playBtn=document.getElementById('play-btn');const progress=document.getElementById('progress');const currentTimeEl=document.getElementById('current-time');const durationEl=document.getElementById('duration');playBtn.addEventListener('click',()=>{if(audio.paused){audio.play();playBtn.querySelector('img').src='icons/pause.svg';}else{audio.pause();playBtn.querySelector('img').src='icons/play.svg';}});audio.addEventListener('loadedmetadata',()=>{durationEl.textContent=formatTime(audio.duration);});audio.addEventListener('timeupdate',()=>{progress.value=(audio.currentTime/audio.duration)*100;currentTimeEl.textContent=formatTime(audio.currentTime);});progress.addEventListener('input',()=>{audio.currentTime=(progress.value/100)*audio.duration;});function formatTime(sec){const m=Math.floor(sec/60);const s=Math.floor(sec%60);return `${m}:${s<10?'0'+s:s}`;}
const startDate = new Date('2024-02-17T00:00:00');
const counterEl = document.getElementById('time-counter');

function updateCounter() {
  const now = new Date();

  let years = now.getFullYear() - startDate.getFullYear();
  let months = now.getMonth() - startDate.getMonth();
  let days = now.getDate() - startDate.getDate();
  let hours = now.getHours() - startDate.getHours();
  let minutes = now.getMinutes() - startDate.getMinutes();
  let seconds = now.getSeconds() - startDate.getSeconds();

  if (seconds < 0) { seconds += 60; minutes--; }
  if (minutes < 0) { minutes += 60; hours--; }
  if (hours < 0) { hours += 24; days--; }
  if (days < 0) {
    const prevMonth = new Date(now.getFullYear(), now.getMonth(), 0);
    days += prevMonth.getDate();
    months--;
  }
  if (months < 0) { months += 12; years--; }

  counterEl.innerHTML = `
    <div><span>${years}</span> Anos</div>
    <div><span>${months}</span> Meses</div>
    <div><span>${days}</span> Dias</div>
    <div><span>${hours}</span> Horas</div>
    <div><span>${minutes}</span> Minutos</div>
    <div><span>${seconds}</span> Segundos</div>
  `;
}
setInterval(updateCounter, 1000);
updateCounter();
